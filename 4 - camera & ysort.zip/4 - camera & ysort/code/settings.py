# game setup
WIDTH    = 800
HEIGTH   = 600
FPS      = 60
TILESIZE = 16




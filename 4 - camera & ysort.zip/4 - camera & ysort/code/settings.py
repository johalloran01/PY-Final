# game setup
WIDTH    = 800
HEIGTH   = 400
FPS      = 60
TILESIZE = 16



